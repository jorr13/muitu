
// Use this file to require additional javascript, e.g require('jquery')
/*import $ from 'jquery'
import jQuery from 'jquery'*/

$ = require('jquery')
jQuery = require('jquery')
//Global vars
