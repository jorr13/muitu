{{--
  Template Name: Pagina de blog
--}}

@extends('layouts.app')

@section('content')


    <posts-loop></posts-loop>

@endsection
