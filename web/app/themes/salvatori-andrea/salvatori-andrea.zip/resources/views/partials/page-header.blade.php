<div class="page-header">
@php

   the_post_thumbnail('post-thumbnail', ['class' => 'img-responsive responsive--full', 'title' => 'Feature image']);
   
@endphp
</div>
