<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('partials.page-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!--slider-->
  <div class="slideshow">
		<div class="tituloslider">
			<h1>Productos recientes</h1>
		</div>
		<ul class="slider"> 
      <?php $__currentLoopData = $products_loop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
			<div class="sliderimagen">
        <!--Esto es el thumb-->
        <?php echo $products['thumbnail']; ?>

			</div>
				<section class="caption">
					<h1><?php echo $products['title']; ?></h1>
          <p><?php echo $products['excerpt']; ?></p>

          <a href=" <?php echo $products['link']; ?>" class="botonfooter">Ver Producto</a>
        </section>
      </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
		<ol class="pagination">
      	
		</ol>
		<div class="left">
			<span class="fa fa-chevron-left"><img src="/app/uploads/2018/06/rigth.png" alt=""></span>
    </div>
    
		<div class="right">
			<span class="fa fa-chevron-right"><img src="/app/uploads/2018/06/left.png" alt=""></span>
		</div>
	</div>
  <!--quienes somos-->
  <?php if(have_rows('seccionuno', 2)): ?>
    
    <?php while(have_rows('seccionuno', 2)): ?><?php (the_row()); ?>
    <div class="seccionuno">
      <div class="contenedorseccionuno contenedorseccionuno is-marginless columns is-multiline">
      	<div class="imgseccion column is-5" style="background:url('<?php echo e(get_sub_field('img')); ?>'); background-size: cover; height: 100%; "></div>	
	      	<div class="conten column is-5">
	      	  <h1 class="titleseccionuno"><?php echo e(get_sub_field('titulo')); ?></h1>
            <p class="contenidouno"><?php echo e(get_sub_field('descripcion')); ?></p>
            <?php ( $link = get_sub_field('boton')); ?>
             <?php if($link): ?> 
             <a class="botonseccion2" href="<?php echo e($link['url']); ?>" target="<?php echo e($link['target']); ?>"><?php echo e($link['title']); ?></a>
            <?php endif; ?>
	    	  </div>	
      </div>
    </div>
    <?php endwhile; ?>
  <?php else: ?>      
  <?php endif; ?>
  <!--nuestros productos-->
  <!--HAMACAS-->
  
      <h1 class="titlenuevo">Lo nuevo de la tienda</h1>

  <div class="posts"> 
      <div class="containerposts containerselec columns is-multiline">
          <a href="#" id="clickhamacas" class="column is-3">HAMACAS</a>
          <a href="#" id="clickbolsos" class="column is-3">BOLSOS</a>
          <a href="#" id="clickcinturnes" class="column is-3">CINTURONES</a>
          <a href="#" id="clickpulceras" class="column is-3">PULCERAS</a>
        </div> 
    <div class="containerposts containerproduct hamacas columns is-multiline" id="hamacas">
      <?php $__currentLoopData = array_slice($category_loop,0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="column productitem is-3">
      <a href=" <?php echo $category['link']; ?>">
        <div class="imgprod">
          <!--Esto es el thumb-->
          <?php echo $category['thumbnail']; ?>

        </div>
          <div class="contenidoproduct">
            <h1><?php echo $category['title']; ?></h1>
          </div>
          <a href=" <?php echo $category['link']; ?>" class="botonproducto">Ver Producto</a>
        </a>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  <!--FIN HAMACAS-->
   <!--BOLSOS-->
   
      <div class="containerposts containerproduct bolsos columns is-multiline" id="bolsos" style="display:none">
        <?php $__currentLoopData = array_slice($bolsos_loop,0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bolsos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="column productitem is-3">
          <a href=" <?php echo $bolsos['link']; ?>">
            <div class="imgprod">
              <!--Esto es el thumb-->
              <?php echo $bolsos['thumbnail']; ?>

            </div>
              <div class="contenidoproduct">
                <h1><?php echo $bolsos['title']; ?></h1>
            </div>
            <a href=" <?php echo $bolsos['link']; ?>" class="botonproducto">Ver Producto</a>
          </a>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

   <!--FIN BOLSOS-->
      <!--CINTURONES-->
    
      <div class="containerposts containerproduct cinturones columns is-multiline" id="cinturones"  style="display:none">
        <?php $__currentLoopData = array_slice($cinturones_loop,0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cinturones): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="column productitem is-3">
            <a href=" <?php echo $cinturones['link']; ?>">
          <div class="imgprod">
            <!--Esto es el thumb-->
            <?php echo $cinturones['thumbnail']; ?>

          </div>
            <div class="contenidoproduct">
              <h1><?php echo $cinturones['title']; ?></h1>
            </div>
            <a href=" <?php echo $cinturones['link']; ?>" class="botonproducto">Ver Producto</a>
            </a>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

   <!--FIN CINTURON-->
    <!--PULCERAS-->  
      <div class="containerposts containerproduct pulceras columns is-multiline" id="pulceras"  style="display:none">
        <?php $__currentLoopData = array_slice($pulceras_loop,0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pulceras): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="column productitem is-3">
            <a href=" <?php echo $pulceras['link']; ?>">
          <div class="imgprod">
            <!--Esto es el thumb-->
            <?php echo $pulceras['thumbnail']; ?>

          </div>
            <div class="contenidoproduct">
              <h1><?php echo $pulceras['title']; ?></h1>
            </div>
            <a href=" <?php echo $pulceras['link']; ?>" class="botonproducto">Ver Producto</a>
            </a>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
  </div>
  <!--FIN PULCERAS-->
  <!--piezas unicas-->
  <?php if(have_rows('secciondos', 2)): ?>
    
    <?php while(have_rows('secciondos', 2)): ?><?php (the_row()); ?>
      <div class="secciondos">
        <div class="contenedorsecciondos is-marginless columns is-multiline">
            <div class="column is-1" style="
            height: 100%;"></div>
            <div class="contendos column is-5">
                <h1 class="titlesecciondos"><?php echo e(get_sub_field('titulo')); ?></h1>
              <p class="contenidodos"><?php echo e(get_sub_field('descripcion')); ?></p>
              <?php ( $link = get_sub_field('boton')); ?>
              <?php if($link): ?>
              <a class="botonseccion" href="<?php echo e($link['url']); ?>" target="<?php echo e($link['target']); ?>"><?php echo e($link['title']); ?></a>
              <?php endif; ?>
          </div>
        <div class="imgseccion column is-5" style="position: absolute;right: 0;
        background-size: cover !important; background-size: cover !important; height: 100%; background:url('<?php echo e(get_sub_field('img')); ?>')"></div>
        </div>
      </div>
    <?php endwhile; ?>
  <?php else: ?>      
  <?php endif; ?>

  <!--articulos recientes-->

  <div class="posts columns">     
    <div class="containerposts columns is-multiline">
        <h1 class="titlearriba">Articulos recientes</h1><br>
        <p class="conteposts">Conoce sobre las comunidades que le han dado vida a cada producto que distribuimos, su cultura, su lenguaje y su amor</p><br>
      <?php $__currentLoopData = array_slice($posts_loop,0,4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="containerpost column is-9">
        <div class="img-container">
        <!--Esto es el thumb-->
        <?php echo $posts['thumbnail']; ?>

        </div>
        <a href=" <?php echo $posts['link']; ?>" class="link posts-link">
        <div class="contenido">
          <h4 class="titleposts posts-title">
          <!--Esto es el titulo-->
          <?php echo $posts['title']; ?></h4>
          <p class="excerpt posts-excerpt">
          <!--esto es el excerpt-->
          <?php echo $posts['excerpt']; ?></p>
        </div>
        </a>
      </div>   
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="column is-12 botoncontainer">
        <a class="botonposts botonfooter" href="/blog/">Ver Posts</a>
      </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>