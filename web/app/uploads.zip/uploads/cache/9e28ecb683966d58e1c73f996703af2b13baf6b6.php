<?php $__env->startSection('content'); ?> 
<div class="contenedor404"><img class="img404" src="<?php echo e(the_field('img_404', 'option')); ?> " alt=""></div>
  <?php if(!have_posts()): ?>
  <div class="posts">     
    <div class="containerposts columns is-multiline">
      <h3 class="error">ERROR 404</h3>
    <p class="nrotlf">No se encontraron resultados, por favor revise su busqueda y intentelo nuevamente.</p>
<div class="contenedorbotones">
    <a href="<?php echo e(home_url('/')); ?>" class="botonproducto">Volver a Inicio</a>
    <a href="/shop" class="botonproducto irtienda">Ir a tienda</a></div>
    </div>
</div>


  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>