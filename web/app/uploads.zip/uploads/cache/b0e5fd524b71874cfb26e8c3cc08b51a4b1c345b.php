<?php $__env->startSection('content'); ?>

<div class="secciondos">
    <div class="contenedorsecciondos is-marginless columns is-multiline">
        <div class="imgparteuno">
            <img class="logoparteuno" src="/app/uploads/2018/06/iso-white.png" alt="" />
        </div>
        <div class="contenidopartedos">
            <h1>Quienes somos</h1>
        </div>
    </div>
</div>
<div class="partedos">
    <p><?php echo e(the_field('partedos', 44)); ?></p>
</div>

<?php if(have_rows('partetres', 44)): ?>

<?php while(have_rows('partetres', 44)): ?><?php (the_row()); ?>
    <div class="parteuno partetres">
        <div class="contenedorsecciondos is-marginless columns is-multiline">
            <div class="contendos column is-5">
              <p class="contenidodos contenidotres"><?php echo e(get_sub_field('partetext')); ?></p>
            </div>
            <div class="imgseccion column is-5" style="position: absolute;right: 0;
            background-size: cover !important; background-size: cover !important; height: 100%; background:url('<?php echo e(get_sub_field('imgcontenedor')); ?>')"></div>
        </div>
    </div>
<?php endwhile; ?>
<?php else: ?>      
<?php endif; ?>

<div class="partedos">
    <p><?php echo e(the_field('seccion_medio', 44)); ?></p>
</div>
<?php if(have_rows('partecuatro', 44)): ?>

<?php while(have_rows('partecuatro', 44)): ?><?php (the_row()); ?>
    <div class="parteuno partecuatro">
        <div class="contenedorseccionuno contenedorseccionuno is-marginless columns is-multiline">
            <div class="imgseccion column is-5" style="background:url('<?php echo e(get_sub_field('imgcontenedordos')); ?>'); background-size: cover; height: 100%; "></div>	
                <div class="conten column is-5">
              <p class="contenidocuatro"><?php echo e(get_sub_field('contenidocuatro')); ?></p>
            </div>
        </div>
    </div>
<?php endwhile; ?>
<?php else: ?>      
<?php endif; ?>
<div class="partedos">
    <div class="titleseccionseis">
        <h1>Nuestra Determinacion</h1>
        <h2>Proposito</h2>
    </div>

<?php if(have_rows('seccion_seis', 44)): ?>

<?php while(have_rows('seccion_seis', 44)): ?><?php (the_row()); ?>
    <div class="parteseis seccionseis">
        <p class="contenidoseis"><?php echo e(get_sub_field('containerArriba')); ?></p>
        <div class="is-marginless columns is-multiline">
            <div class="primeraimagen column is-4" style="background:url('<?php echo e(get_sub_field('primeraImagen')); ?>'); background-size: cover; height: 240px;"></div>
            <div class="containerverde column is-4"></div>	
        </div>
    </div>
<?php endwhile; ?>
<?php else: ?>      
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>