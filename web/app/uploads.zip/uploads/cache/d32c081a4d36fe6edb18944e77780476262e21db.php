<?php $__env->startSection('content'); ?>
  <?php while(have_posts()): ?> <?php the_post() ?>
    <?php echo $__env->make('partials.page-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.content-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <div class="posts columns">     
    <div class="containerposts columns is-multiline">
        <h1 class="titlearriba">Articulos recientes</h1><br>
        <p class="conteposts">Conoce sobre las comunidades que le han dado vida a cada producto que distribuimos, su cultura, su lenguaje y su amor</p><br>
         
    <!--Esta pagina es de productos-->
    <?php $__currentLoopData = $posts_loop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="containerpost column is-9">
      <div class="img-container">
      <!--Esto es el thumb-->
      <?php echo $posts['thumbnail']; ?>

      </div>
      <a href=" <?php echo $posts['link']; ?>" class="link posts-link">
      <div class="contenido">
        <h4 class="titleposts posts-title">
        <!--Esto es el titulo-->
        <?php echo $posts['title']; ?></h4>
        <p class="excerpt posts-excerpt">
        <!--esto es el excerpt-->
        <?php echo $posts['excerpt']; ?></p>
      </div>
      </a>
    </div>   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
  <?php endwhile; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>